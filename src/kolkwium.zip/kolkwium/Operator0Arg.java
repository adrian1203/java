package kolkwium;

public class Operator0Arg extends Operator {

}
