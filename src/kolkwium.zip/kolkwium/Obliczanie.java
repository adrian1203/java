package kolkwium;

import java.util.Stack;

interface Obliczanie {
    public double oblicz(Stack<Operator> o);
}
