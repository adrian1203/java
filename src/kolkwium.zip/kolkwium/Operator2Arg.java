package kolkwium;

public class Operator2Arg extends  Operator{
}
