package kolkwium;

public class Operator1Arg extends Operator {
}
